语言包介绍：

名称：简体中文-Flash_Demo1.0
作者：是闪闪闪闪闪（bilibili_UID：545576624）
简介：本语言包修改自游戏《SCP Secret Laboratory》官方简体中文语言包，其修改内容主要为字体美化。
制作版本：本语言包制作于13.4.2版本

使用方法：

将"zh_Flash"文件夹拖拽至游戏根目录中的"Translations"文件夹内即可。